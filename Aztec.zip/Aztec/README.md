# Aztec Network
Privacy-first ZK Layer 2 with encrypted smart contracts.